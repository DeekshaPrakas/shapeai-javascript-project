import React from "react";

function Footer(){
  return(
    <p>
      copyright by ShapeAI @ {new Date().getFullYear()}
      </p>
  );
}
 export default Footer;
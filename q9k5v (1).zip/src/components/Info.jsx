import React from "react";

function Info(){
  return(
    <div className="note">
      <h1>Javascript and React.js </h1>
      <p>a basic web dev React JsBootcamp</p> 
      </div>

  );
}
 export default Info;